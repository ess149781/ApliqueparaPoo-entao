import java.util.ArrayList;
/* RESPOSTAS DAS QUESTÕES AQUI
 * Nome: ---------
 * RA: --------
 * 
 * (R1):
 * 
 * (R2):
 * 
 * (R3):
 * 
 * 
 * (R4):
 * 
 * 
 * (R5):
 * 
 * 
 */
// (Q1): Explique para que serve o método super().
// (Q2): Explique qual a vantagem de declarar o escopo das variáveis como protected ao invés de public ou private.
// (Q3): Explique qual a diferença de métodos abstratos para métodos não-abstratos.
// (Q4): Explique qual a utilidade das classes abstratas.
// (Q5): Como você implementaria em seu Motor, em termos de código, para verificar se um lacaio já atacou naquele turno ? Usaria alguma classe da biblioteca do Java ?

// Classe Motor do aluno RA XXXXXX para o Lab5.
public class MotorXXXXXX extends MotorAbstrato {

	protected MotorXXXXXX(Baralho deck1, Baralho deck2, ArrayList<Carta> mao1, ArrayList<Carta> mao2, Jogador jogador1, Jogador jogador2, int verbose, Verificador verificador) {
		super(deck1, deck2, mao1, mao2, jogador1, jogador2, verbose, verificador);
	}
	
	private int jogador; // Este atributo identifica se estamos processando as jogadas do primeiro jogador (1) ou do segundo (2).

	@Override
	public boolean executarPartida() {
		
		for(int turno = 1; turno < 40; turno++){
			System.out.println("=============================================== Início do Turno "+turno +" ==================");
			
			ArrayList<Jogada> movimentosJog1, movimentosJog2;
			movimentosJog2 = new ArrayList<Jogada>();
			int nCartasJog1 = mao1.size()+1;
			if(nCartasJog1 > 10) nCartasJog1 = 10;
			
			// Contexto do jogador 1
			jogador = 1;
			
			System.out.println("Enviando mesa e dados para jogador 1...");
			
			Mesa mesa = new Mesa(lacaiosMesa1, lacaiosMesa2, vidaHeroi1, vidaHeroi2, nCartasJog1, mao2.size(), turno, turno==1?2:turno);
			
			if( deck1.getCartas().size() > 0){
				if(mao1.size() >= 10){
					movimentosJog1 = jogador1.processarTurno(mesa, null, movimentosJog2);
					deck1.comprarCarta();
				}
				else{
					Carta cartaCompradaEsteTurno = deck1.comprarCarta();
					movimentosJog1 = jogador1.processarTurno(mesa, cartaCompradaEsteTurno, movimentosJog2);
				}
			}
			else{
				movimentosJog1 = jogador1.processarTurno(mesa, null, movimentosJog2);
			}
			
			System.out.println("Processando jogadas do jogador 1:");
			
			for(int i = 0; i < movimentosJog1.size(); i++){
				processarJogada (movimentosJog1.get(i));
			}
			
			// Mudando o contexto para o jogador 2
			jogador = 2;

			System.out.println("Enviando mesa e dados para jogador 2...");
			int nCartasJog2 = mao2.size()+1;
			if(nCartasJog2 > 10) nCartasJog2 = 10;
			
			mesa = new Mesa(lacaiosMesa1, lacaiosMesa2, vidaHeroi1, vidaHeroi2, mao1.size(), nCartasJog2, turno, turno==1?2:turno);
			
			if( deck2.getCartas().size() > 0){
				if(mao2.size() >= 10){
					movimentosJog2 = jogador2.processarTurno(mesa, null, movimentosJog1);
					deck2.comprarCarta();
				}
				else{
					Carta cartaCompradaEsteTurno = deck2.comprarCarta();
					movimentosJog2 = jogador2.processarTurno(mesa, cartaCompradaEsteTurno, movimentosJog1);
				}
			}
			else{
				movimentosJog2 = jogador2.processarTurno(mesa, null, movimentosJog1);
			}
			
			System.out.println("Processando jogadas do jogador 2:");
			
			for(int i = 0; i < movimentosJog2.size(); i++){
				processarJogada (movimentosJog2.get(i));
			}
		}
		
		return true;
	}

	@Override
	protected void processarJogada(Jogada umaJogada) {
		switch(umaJogada.getTipo()){
		case ATAQUE:
			// TODO: Um ataque foi realizado... quem atacou? quem foi atacado? Trate o caso do herói como alvo também.		
			break;
		case LACAIO:
			int lacaioID = umaJogada.getCartaJogada().getID();
			System.out.println("JOGADA: O lacaio_id="+lacaioID+" foi baixado para a mesa.");
			if(jogador == 1){
				if(mao1.contains(umaJogada.getCartaJogada())){
					Carta lacaioBaixado = mao1.get(mao1.indexOf(umaJogada.getCartaJogada()));
					lacaiosMesa1.add(lacaioBaixado);
					mao1.remove(umaJogada.getCartaJogada());
				}
			}
			else{
				if(mao2.contains(umaJogada.getCartaJogada())){
					Carta lacaioBaixado = mao2.get(mao2.indexOf(umaJogada.getCartaJogada()));
					lacaiosMesa2.add(lacaioBaixado);
					mao2.remove(umaJogada.getCartaJogada());
				}
			}
			break;
		case MAGIA:
			// TODO: Uma magia foi usada... é de área ou alvo? Se de alvo, qual o alvo ?
			break;
		case PODER:
			// TODO: O poder heroico foi usado... Foi no outro heroi ou em qual lacaio ?
			break;
		default:
			break;
		}
	}
}

/* Lista de atributos herdados da classe MotorAbstrato.
 * 
 *  protected Jogador jogador1;
	protected Jogador jogador2;
	
	protected Baralho deck1;
	protected Baralho deck2;
	
	protected ArrayList<Carta> mao1;
	protected ArrayList<Carta> mao2;
	
	protected ArrayList<Carta> lacaiosMesa1;
	protected ArrayList<Carta> lacaiosMesa2;
	
	protected int vidaHeroi1;
	protected int vidaHeroi2;
	
	protected int manaHeroi1;
	protected int manaHeroi2;
 */

