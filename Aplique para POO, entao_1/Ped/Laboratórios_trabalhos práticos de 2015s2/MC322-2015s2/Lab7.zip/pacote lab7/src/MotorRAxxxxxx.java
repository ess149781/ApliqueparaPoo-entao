import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
/* Laboratório 7
 * Nome: 
 * RA: 
 * 
 * Completude: X (De 0 a 10, escreva quanto você acha que "completou" das atividades propostas)
 * Escreva aqui (sucintamente) os tratamentos que você implementou: 
 * Escreva aqui (sucintamente) o que faltou você implementar: 
 * 
 * Obs: Este formulário não irá implicar em sua nota, apenas serve para facilitar o processo de correção.
 */

public class MotorRAxxxxxx extends Motor {

	public MotorRAxxxxxx(Baralho deck1, Baralho deck2, ArrayList<Carta> mao1,
			ArrayList<Carta> mao2, Jogador jogador1, Jogador jogador2,
			int verbose, int tempoLimitado, PrintWriter saidaArquivo) {
		super(deck1, deck2, mao1, mao2, jogador1, jogador2, verbose,
				tempoLimitado, saidaArquivo);
		// TODO Auto-generated constructor stub
	}
	
	private int jogador; // 1== turno do jogador1, 2 == turno do jogador2
	private int turno;
	private int nCartasHeroi1;
	private int nCartasHeroi2;
	
	private Mesa mesa;
	
	// "Apontadores" - Assim pode-se programar genericamente os métodos para funcionar com ambos os jogadores
	private ArrayList<Carta> mao;
	private ArrayList<Carta> lacaios;
	private ArrayList<Carta> lacaiosOponente;
	
	// "Memória" - Para marcar Jogadas que só podem ser realizadas uma vez por turno.
	private boolean poderHeroicoUsado;
	private HashSet<Integer> lacaiosAtacaramID;

	@Override
	public GameStatus executarPartida() {
		vidaHeroi1 = vidaHeroi2 = 30;
		manaJogador1 = manaJogador2 = 1;
		nCartasHeroi1 = cartasIniJogador1; 
		nCartasHeroi2 = cartasIniJogador2;
		ArrayList<Jogada> movimentos = new ArrayList<Jogada>();
		int noCardDmgCounter1 = 1;
		int noCardDmgCounter2 = 1;
		turno = 1;
		
		for(int k = 0; k < 60; k++){
			imprimir("\n=== TURNO "+turno+" ===\n");
			// Atualiza mesa
			@SuppressWarnings("unchecked")
			ArrayList<Carta> lacaios1clone = (ArrayList<Carta>) UnoptimizedDeepCopy.copy(lacaiosMesa1);
			@SuppressWarnings("unchecked")
			ArrayList<Carta> lacaios2clone = (ArrayList<Carta>) UnoptimizedDeepCopy.copy(lacaiosMesa2);
			mesa = new Mesa(lacaios1clone, lacaios2clone, vidaHeroi1, vidaHeroi2, nCartasHeroi1+1, nCartasHeroi2, turno>10?10:turno, turno>10?10:(turno==1?2:turno));
			
			// Apontadores para jogador1
			mao = maoJogador1;
			lacaios = lacaiosMesa1;
			lacaiosOponente = lacaiosMesa2;
			jogador = 1;
			
			// Processa o turno 1 do Jogador1
			imprimir("\n----------------------- Começo de turno para Jogador 1:");
			long startTime, endTime, totalTime;
			
			// Copia de movimentos da mão (do contrário pode referenciar cartas do campo do outro jogador e confundi-lo).
			@SuppressWarnings("unchecked")
			ArrayList<Jogada> cloneMovimentos1 = (ArrayList<Jogada>) UnoptimizedDeepCopy.copy(movimentos);
			
			startTime = System.nanoTime();
			if( baralho1.getCartas().size() > 0){
				if(nCartasHeroi1 >= 10){
					movimentos = jogador1.processarTurno(mesa, null, cloneMovimentos1);
					comprarCarta(); // carta descartada
				}
				else
					movimentos = jogador1.processarTurno(mesa, comprarCarta(), cloneMovimentos1);
			}
			else{
				imprimir("Fadiga: O Herói 1 recebeu "+noCardDmgCounter1+" de dano por falta de cartas no baralho. (Vida restante: "+(vidaHeroi1-noCardDmgCounter1)+").");
				vidaHeroi1 -= noCardDmgCounter1++;
				if( vidaHeroi1 <= 0){
					// Jogador 2 venceu
					imprimir("O jogador 2 venceu porque o jogador 1 recebeu um dano mortal por falta de cartas ! (Dano : " +(noCardDmgCounter1-1)+ ", Vida Herói 1: "+vidaHeroi1+")");
					return null;
				}
				movimentos = jogador1.processarTurno(mesa, null, cloneMovimentos1);
			}
			endTime = System.nanoTime();
			totalTime = endTime - startTime;
			if( tempoLimitado!=0 && totalTime > 3e8){ // 300ms
				// Jogador 2 venceu, Jogador 1 excedeu limite de tempo
				return null;
			}
			else
				imprimir("Tempo usado em processarTurno(): "+totalTime/1e6+"ms");

			// Começa a processar jogadas do Jogador 1
			this.poderHeroicoUsado = false;
            this.lacaiosAtacaramID = new HashSet<Integer>();
			for(int i = 0; i < movimentos.size(); i++){
				GameStatus status = processarJogada (movimentos.get(i));
				if(status != null){
					// Erro foi detecado.
					return status;
				}
			}
			
			if( vidaHeroi2 <= 0){
				// Jogador 1 venceu
				return null;
			}
			
			// Atualiza mesa
			@SuppressWarnings("unchecked")
			ArrayList<Carta> lacaios1clone2 = (ArrayList<Carta>) UnoptimizedDeepCopy.copy(lacaiosMesa1);
			@SuppressWarnings("unchecked")
			ArrayList<Carta> lacaios2clone2 = (ArrayList<Carta>) UnoptimizedDeepCopy.copy(lacaiosMesa2);
			mesa = new Mesa(lacaios1clone2, lacaios2clone2, vidaHeroi1, vidaHeroi2, nCartasHeroi1, nCartasHeroi2+1, turno>10?10:turno, turno>10?10:(turno==1?2:turno));
			
			// Apontadores para jogador2
			mao = maoJogador2;
			lacaios = lacaiosMesa2;
			lacaiosOponente = lacaiosMesa1;
			jogador = 2;
			
			// Processa o turno 1 do Jogador2
			imprimir("\n\n----------------------- Começo de turno para Jogador 2:");
			
			// Copia de movimentos da mão.
			@SuppressWarnings("unchecked")
			ArrayList<Jogada> cloneMovimentos2 = (ArrayList<Jogada>) UnoptimizedDeepCopy.copy(movimentos);
			
			startTime = System.nanoTime();

			
			if( baralho2.getCartas().size() > 0){
				if(nCartasHeroi2 >= 10){
					movimentos = jogador2.processarTurno(mesa, null, cloneMovimentos2);
					comprarCarta(); // carta descartada
				}
				else
					movimentos = jogador2.processarTurno(mesa, comprarCarta(), cloneMovimentos2);
			}
			else{
				imprimir("Fadiga: O Herói 2 recebeu "+noCardDmgCounter2+" de dano por falta de cartas no baralho. (Vida restante: "+(vidaHeroi2-noCardDmgCounter2)+").");
				vidaHeroi2 -= noCardDmgCounter2++;
				if( vidaHeroi2 <= 0){
					// Vitoria do jogador 1
					imprimir("O jogador 1 venceu porque o jogador 2 recebeu um dano mortal por falta de cartas ! (Dano : " +(noCardDmgCounter2-1)+ ", Vida Herói 2: "+vidaHeroi2 +")");
					return null;
				}
				movimentos = jogador2.processarTurno(mesa, null, cloneMovimentos2);
			}
						
			endTime = System.nanoTime();
			totalTime = endTime - startTime;
			if( tempoLimitado!=0 && totalTime > 3e8){ // 300ms
				// Limite de tempo pelo jogador 2. Vitoria do jogador 1.
			}
			else
				imprimir("Tempo usado em processarTurno(): "+totalTime/1e6+"ms");
			
			this.poderHeroicoUsado = false;
            this.lacaiosAtacaramID = new HashSet<Integer>();
			for(int i = 0; i < movimentos.size(); i++){
				GameStatus status = processarJogada (movimentos.get(i));
				if(status != null){
					// Erro foi detecado.
					return status;
				}
			}
			if( vidaHeroi1 <= 0){
				// Vitoria do jogador 2
				return null;
			}
			turno++;
		}
		
		// Nunca vai chegar aqui dependendo do número de rodadas
		imprimir("Erro: A partida não pode ser determinada em mais de 60 rounds. Provavel BUG.");
		return null;
	}

	@Override
	protected GameStatus processarJogada(Jogada umaJogada) {
		// TODO Auto-generated method stub
		Mesa mesaAntesJogada = gerarMesaAtual();
		switch(umaJogada.getTipo()){
		case ATAQUE:
			// TODO: Um ataque foi realizado... quem atacou? quem foi atacado? qual o dano? o alvo morreu ou ficou com quanto de vida? Trate o caso do herói como alvo também. (Atividade do Lab6)
			break;
		case LACAIO:
			int lacaioID = umaJogada.getCartaJogada().getID();
			imprimir("JOGADA: O lacaio_id="+lacaioID+" foi baixado para a mesa.");
			if(mao.contains(umaJogada.getCartaJogada())){
				Carta lacaioBaixado = mao.get(mao.indexOf(umaJogada.getCartaJogada()));
				lacaios.add(lacaioBaixado); // lacaio adicionado à mesa
				mao.remove(umaJogada.getCartaJogada()); // lacaio retirado da mão
			}
			else{
				String erroMensagem = "Erro: Tentou-se baixar o lacaio_id="+lacaioID+", porém esta carta não existe nada mao. IDs de cartas na mao: ";
				for(Carta card : mao){
					erroMensagem += card.getID() + ", ";
				}
				imprimir(erroMensagem);
				GameStatus erroCartaNaoExistente = new GameStatus(1, jogador==1?2:1, umaJogada, mesaAntesJogada, erroMensagem);
				return erroCartaNaoExistente;
			}
			// Obs: repare que este código funcionará tanto para o jogador1 ou jogador2. Como ?
			// Obs2: está faltando a verificação do limite de 7 lacaios na mesa.
			break;
		case MAGIA:
			// TODO: Uma magia foi usada... é de área ou alvo? Se de alvo, qual o alvo ? (Atividade do Lab7)
			break;
		case PODER:
			// TODO: O poder heroico foi usado... Foi no outro heroi ou em qual lacaio ? (Atividade do Lab7)
			break;
		default:
			break;
		}
		return null;
	}
	
	private Mesa gerarMesaAtual(){
		// Atualiza mesa
		@SuppressWarnings("unchecked")
		ArrayList<Carta> lacaios1clone = (ArrayList<Carta>) UnoptimizedDeepCopy.copy(lacaiosMesa1);
		@SuppressWarnings("unchecked")
		ArrayList<Carta> lacaios2clone = (ArrayList<Carta>) UnoptimizedDeepCopy.copy(lacaiosMesa2);
		Mesa currentMesa = new Mesa(lacaios1clone, lacaios2clone, vidaHeroi1, vidaHeroi2, maoJogador1.size(), maoJogador2.size(), turno>10?10:turno, turno>10?10:(turno==1?2:turno));
		return currentMesa;
	}
	
	private Carta comprarCarta(){
		if(this.jogador == 1){
			if(baralho1.getCartas().size() <= 0)
				throw new RuntimeException("Não há mais cartas no baralho para serem compradas.");
			Carta nova = baralho1.comprarCarta();
			mao.add(nova);
			nCartasHeroi1++;
			return (Carta) UnoptimizedDeepCopy.copy(nova);
		}
		else{
			if(baralho2.getCartas().size() <= 0)
				throw new RuntimeException("Não há mais cartas no baralho para serem compradas.");
			Carta nova = baralho2.comprarCarta();
			mao.add(nova);
			nCartasHeroi2++;
			return (Carta) UnoptimizedDeepCopy.copy(nova);
		}
	}

}

