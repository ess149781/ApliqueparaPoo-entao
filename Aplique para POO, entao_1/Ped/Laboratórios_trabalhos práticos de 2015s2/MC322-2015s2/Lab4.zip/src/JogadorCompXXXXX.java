import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
* Esta classe representa um Jogador para o Jogo LaMa (Lacaios & Magias). Laboratório 4.
* @see java.lang.Object
* @author MO322
*/

//ATENÇÃO: Modifique o nome da classe 'JogadorCompXXXXX' substituindo XXXXX pelo seu RA.
// Obs: Será necessário renomear também o construtor.

public class JogadorCompXXXXX extends Jogador implements Comparator<Carta> {
	
	// Atributo que regula a comparação entre cartas
	private enum ComparaCartas {COMPARA_VIDA, COMPARA_MANA, COMPARA_ATAQUE, COMPARA_TIPO, COMPARA_PERSONALIZADO};
	private ComparaCartas modoComparacao = ComparaCartas.COMPARA_ATAQUE;
	
	/**
	  * O método construtor do JogadorAleatorio.
	  * 
	  * @param maoInicial Contém a mão inicial do jogador. Deve conter o número de cartas correto dependendo se esta classe Jogador que está sendo construída é o primeiro ou o segundo jogador da partida. 
	  * @param primeiro   Informa se esta classe Jogador que está sendo construída é o primeiro jogador a iniciar nesta jogada (true) ou se é o segundo jogador (false).
	  * @return            um objeto JogadorAleatorio
	  */
	public JogadorCompXXXXX(ArrayList<Carta> maoInicial, boolean primeiro){
		primeiroJogador = primeiro;
		mao = maoInicial;
	}
	
	/**
	  * Um método que processa o turno de cada jogador. Este método deve retornar as jogadas do Jogador correspondente para o turno atual (ArrayList de Jogada).
	  * 
	  * @param mesa   O "estado do jogo" imediatamente antes do início do turno corrente. Este objeto de mesa contém todas as informações 'públicas' do jogo (lacaios vivos e suas vidas, vida dos heróis, etc).
	  * @param cartaComprada   A carta que o Jogador recebeu neste turno (comprada do Baralho). Obs: pode ser null se o Baralho estiver vazio ou o Jogador possuir mais de 10 cartas na mão.
	  * @param jogadasOponente   Um ArrayList de Jogada que foram os movimentos utilizados pelo oponente no último turno, em ordem.
	  * @return            um ArrayList com as Jogadas decididas
	  */
	public ArrayList<Jogada> processarTurno (Mesa mesa, Carta cartaComprada, ArrayList<Jogada> jogadasOponente){
		if(cartaComprada != null)
			mao.add(cartaComprada);
		
		ArrayList<Jogada> minhasJogadas = new ArrayList<Jogada>();
		
		// Impressão das cartas da mão em ordem
		Collections.sort(mao,this);
		System.out.println(mao);
		System.exit(0);
		
		return minhasJogadas;
	}

	@Override
	public int compare(Carta arg0, Carta arg1) {
		switch (modoComparacao) {
			case COMPARA_ATAQUE: // Ordem decrescente de ataque
				return arg1.getAtaque() - arg0.getAtaque();
			case COMPARA_MANA:
				return 0; // incompleto
			case COMPARA_TIPO:
				return 0; // incompleto
			case COMPARA_VIDA:
				return 0; // incompleto
			case COMPARA_PERSONALIZADO:
				return 0; // incompleto
			default:
				break;
		}
		return 0;
	}
}
