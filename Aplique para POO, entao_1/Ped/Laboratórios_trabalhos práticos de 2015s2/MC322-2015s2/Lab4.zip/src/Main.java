import java.util.ArrayList;

// Classe Main para ser utilizada no Laboratório 4.
// ATENÇÃO: Modifique o nome da classe 'JogadorCompXXXXX' substituindo XXXXX pelo seu RA.

public class Main {
	public static void main(String[] args) {
		Baralho baralho1 = new Baralho(Motor.gerarListaCartasPadrao(0));
		Baralho baralho2 = new Baralho(Motor.gerarListaCartasPadrao(1));
		Baralho.setDeterministico(true);
		umaPartida(baralho1, baralho2, 0);
	}
	
	private static void umaPartida(Baralho baralho1, Baralho baralho2, int verbosidade){
		// Embaralha os Baralhos
		baralho1.embaralhar();
		baralho2.embaralhar();
		
		// Declara estruturas que armazenam as cartas da mão
		ArrayList<Carta> Mao1, Mao2;
		Mao1 = new ArrayList<Carta>();
		Mao2 = new ArrayList<Carta>();
		
		// Adiciona cartas à mão de cada jogador com o número de cartas correspondente (para o primeiro Jogador é Motor.cartasIniJogador1 cartas, e para o segundo Jogador é Motor.cartasIniJogador2).
		for(int i = 0; i < Motor.cartasIniJogador1; i++){
			Mao1.add(baralho1.getCartas().get(0));
			baralho1.getCartas().remove(0);
		}
		for(int i = 0; i < Motor.cartasIniJogador2; i++){
			Mao2.add(baralho2.getCartas().get(0));
			baralho2.getCartas().remove(0);
		}
		
		// Inicializa uma cópia para ser enviada ao Jogador das cartas da mão
		@SuppressWarnings("unchecked")
		ArrayList<Carta> mao1clone = (ArrayList<Carta>) UnoptimizedDeepCopy.copy(Mao1);
		@SuppressWarnings("unchecked")
		ArrayList<Carta> mao2clone = (ArrayList<Carta>) UnoptimizedDeepCopy.copy(Mao2);
		
		// Inicializa os Jogadores devidamente (com as cartas da mão e o argumento 'primeiro').
		//JogadorAleatorioNewbie jogA = new JogadorAleatorioNewbie(mao1clone, true);
		//JogadorAleatorioFace jogB = new JogadorAleatorioFace(mao2clone, false);
		JogadorCompXXXXX jogA = new JogadorCompXXXXX(mao1clone, true);
		JogadorAleatorio jogB = new JogadorAleatorio(mao2clone, false);
		
		// O Motor é construído
		Motor partida = new Motor(baralho1, baralho2, Mao1, Mao2, jogA, jogB, verbosidade);
		
		// Verifica o vencedor da partida
		if(partida.executarPartida())
			System.out.println("A classe jogA venceu!");
		else
			System.out.println("A classe jogB venceu!");
	}
}

