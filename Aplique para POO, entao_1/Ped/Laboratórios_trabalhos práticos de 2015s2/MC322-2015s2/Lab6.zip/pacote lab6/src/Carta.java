/**
* Esta classe representa uma Carta, que pode ser do tipo Lacaio ou Magia.
* @see java.lang.Object
* @author MO322
*/
public class Carta implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int ID; // número identificador da carta (gerado pelo Motor).
	private String nome;
	private TipoCarta tipo; // TipoCarta.LACAIO == Carta Lacaio, TipoCarta.MAGIA == Carta de Magia.
	private int ataque;
	private int vida;
	private int vidaMesa;
	private int mana;
	private TipoMagia magiaTipo; // TipoMagia.ALVO ==Dano em alvo, TipoMagia.AREA == Dano em area.
	private int magiaDano;
	private int turno;
	
	/**
	  * Construtor da classe Carta para uma CARTA LACAIO.
	  * 
	  * @param id   Um inteiro identificador ÚNICO para esta carta
	  * @param nome   O nome da carta
	  * @param tipo   O tipo da carta (ver enumeração TipoCarta): TipoCarta.LACAIO ou TipoCarta.MAGIA
	  * @param ataque   O ataque deste lacaio
	  * @param vida   A vida maxima deste lacaio
	  * @param vidaMesa   A vida na mesa deste lacaio (vida atual após sofrer danos de magias, ataques, etc)
	  * @param mana   O custo de mana deste lacaio
	  * @return            um objeto Carta
	  */
	public Carta(int id, String nome, TipoCarta tipo, int ataque, int vida, int vidaMesa, int mana) {
		this.ID = id;
		this.nome = nome;
		this.tipo = tipo;
		this.ataque = ataque;
		this.vida = vida;
		this.vidaMesa = vidaMesa;
		this.mana = mana;
		this.turno = -1;
		// Apenas preenchendo com algo inutil
		this.magiaTipo = TipoMagia.ALVO;
		this.magiaDano = 0;
	}
	
	/**
	  * Construtor da classe Carta para uma CARTA MAGIA.
	  * 
	  * @param id   Um inteiro identificador ÚNICO para esta carta
	  * @param nome   O nome da carta
	  * @param tipo   O tipo da carta (ver enumeração TipoCarta): TipoCarta.LACAIO ou TipoCarta.MAGIA
	  * @param magiaTipo   O tipo de magia (ver enumeração TipoMagia): Tipo
	  * @param magiaDano   O dano causado por esta magia
	  * @param mana   O custo de mana desta magia
	  * @return            um objeto Carta
	  */
	public Carta(int id, String nome, TipoCarta tipo, TipoMagia magiaTipo, int magiaDano, int mana) {
		this.ID = id;
		this.nome = nome;
		this.tipo = tipo;
		this.magiaTipo = magiaTipo;
		this.magiaDano = magiaDano;
		this.mana = mana;
		// Apenas preenchendo com algo inutil
		this.ataque = 0;
		this.vida = 0;
		this.vidaMesa = 0;
		this.turno = -1;
	}

	/**
	  * Recupera o atributo ID.
	  * 
	  * @return            o atributo
	  */
	public int getID() {
		return ID;
	}

	/**
	  * Modifica o atributo ID.
	  * 
	  * @param iD   Novo valor para o atributo.
	  */
	public void setID(int iD) {
		ID = iD;
	}

	/**
	  * Recupera o atributo nome.
	  * 
	  * @return            o atributo
	  */
	public String getNome() {
		return nome;
	}

	/**
	  * Modifica o atributo nome.
	  * 
	  * @param nome   Novo valor para o atributo.
	  */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	  * Recupera o atributo tipo.
	  * 
	  * @return            o atributo
	  */
	public TipoCarta getTipo() {
		return tipo;
	}

	/**
	  * Modifica o atributo tipo.
	  * 
	  * @param tipo   Novo valor para o atributo.
	  */
	public void setTipo(TipoCarta tipo) {
		this.tipo = tipo;
	}

	/**
	  * Recupera o atributo ataque.
	  * 
	  * @return            o atributo
	  */
	public int getAtaque() {
		return ataque;
	}

	/**
	  * Modifica o atributo ataque.
	  * 
	  * @param ataque   Novo valor para o atributo.
	  */
	public void setAtaque(int ataque) {
		this.ataque = ataque;
	}

	/**
	  * Recupera o atributo vida.
	  * 
	  * @return            o atributo
	  */
	public int getVida() {
		return vida;
	}

	/**
	  * Modifica o atributo vida.
	  * 
	  * @param vida   Novo valor para o atributo.
	  */
	public void setVida(int vida) {
		this.vida = vida;
	}

	/**
	  * Recupera o atributo vidaMesa.
	  * 
	  * @return            o atributo
	  */
	public int getVidaMesa() {
		return vidaMesa;
	}

	/**
	  * Modifica o atributo vidaMesa.
	  * 
	  * @param vidaMesa   Novo valor para o atributo.
	  */
	public void setVidaMesa(int vidaMesa) {
		this.vidaMesa = vidaMesa;
	}

	/**
	  * Recupera o atributo mana.
	  * 
	  * @return            o atributo
	  */
	public int getMana() {
		return mana;
	}

	/**
	  * Modifica o atributo mana.
	  * 
	  * @param mana   Novo valor para o atributo.
	  */
	public void setMana(int mana) {
		this.mana = mana;
	}

	/**
	  * Recupera o atributo magiaTipo.
	  * 
	  * @return            o atributo
	  */
	public TipoMagia getMagiaTipo() {
		return magiaTipo;
	}

	/**
	  * Modifica o atributo magiaTipo.
	  * 
	  * @param magiaTipo   Novo valor para o atributo.
	  */
	public void setMagiaTipo(TipoMagia magiaTipo) {
		this.magiaTipo = magiaTipo;
	}

	/**
	  * Recupera o atributo magiaDano.
	  * 
	  * @return            o atributo
	  */
	public int getMagiaDano() {
		return magiaDano;
	}

	/**
	  * Modifica o atributo magiaDano.
	  * 
	  * @param magiaDano   Novo valor para o atributo.
	  */
	public void setMagiaDano(int magiaDano) {
		this.magiaDano = magiaDano;
	}

	/**
	  * Recupera o atributo turno.
	  * 
	  * @return            o atributo
	  */
	public int getTurno() {
		return turno;
	}

	/**
	  * Modifica o atributo turno.
	  * 
	  * @param turno   Novo valor para o atributo.
	  */
	public void setTurno(int turno) {
		this.turno = turno;
	}

	/**
	  * Cria uma String com os dados de uma carta.
	  * 
	  * return String   uma String com algumas informações da carta descritas de uma maneira estética.
	  */
	@Override
	public String toString() {
		String out = "";
		if(tipo == TipoCarta.LACAIO){
			out = out + getNome();
			out = out + " (Atq = "+getAtaque()+", ";
			out = out + "Vida = ("+getVidaMesa() + "/" +getVida()+")). ";
			out = out + "Mana = "+getMana() + "\n";
		}
		else{
			if (magiaTipo == TipoMagia.ALVO){
				out = out + getNome()+" ";
				out = out + "("+getMagiaDano()+" dano em Alvo). ";
				out = out + "Mana = "+getMana() + "\n";
			}
			else{
				out = out + getNome()+" ";
				out = out + "("+getMagiaDano()+" dano em Area). ";
				out = out + "Mana = "+getMana() + "\n";
			}
		}
		return out;
	}
	
	@Override
	public boolean equals(Object aThat) {
	    //check for self-comparison
	    if ( this == aThat ) return true;

	    //use instanceof instead of getClass here for two reasons
	    //1. if need be, it can match any supertype, and not just one class;
	    //2. it renders an explict check for "that == null" redundant, since
	    //it does the check for null already - "null instanceof [type]" always
	    //returns false. (See Effective Java by Joshua Bloch.)
	    if ( !(aThat instanceof Carta) ) return false;
	    //Alternative to the above line :
	    //if ( aThat == null || aThat.getClass() != this.getClass() ) return false;

	    //cast to native object is now safe
	    Carta that = (Carta)aThat;

	    //now a proper field-by-field evaluation can be made
	    return this.ID == that.getID();
	  }

}