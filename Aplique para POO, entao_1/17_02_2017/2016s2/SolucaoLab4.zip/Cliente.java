/*
 * Cliente.java
 * 
 * Última modificação: 01/10/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */

import java.util.ArrayList;

/**
 *  Classe Cliente referente ao Lab4
 */
public class Cliente
{
	private String nome;				// propriedade nome do cliente
	private String cpf;					// propriedade cpf do cliente
	private String endereco;			// propriedade endereço do cliente

	public Cliente(String nome, String cpf, String endereco) 
	{
		this.nome = nome;
		this.cpf = cpf;
		this.endereco = endereco;
	}
	
	public String getNome() 
	{
		return nome;
	}
	
	public String getCpf() 
	{
		return cpf;
	}

	public String getEndereco() 
	{
		return endereco;
	}

	/*   @Override   */
	public String toString() 
	{
		String out = ""; 
		out += "Cliente: "+getNome()+" de cpf # "+ getCpf() + "\nEndereço: " + getEndereco(); 
		return out; 
	}
}