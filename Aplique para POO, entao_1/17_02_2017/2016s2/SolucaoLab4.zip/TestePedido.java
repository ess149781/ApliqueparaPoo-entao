/*
 * TestePedido.java
 * 
 * Última modificação: 01/10/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *  Classe utilizada para instaciar objetos da classe Produto, Perecivel, Item, Fornecedor, Cliente e Pedido
 *  referente ao lab 4
 *  Usa as classes Produto.java, Perecivel.java, Item.java, Fornecedor.java, Cliente.java, Data.java e Pedido.java
 */

public class TestePedido 
{
	public static void main(String[] argv) throws Exception 
	{
		String n, t;
		int c;

		InputStreamReader reader = new InputStreamReader(System.in);
		BufferedReader in = new BufferedReader(reader);

		System.out.println("***********************************************************************");
		System.out.print("Entre com as informações do fornecedor:\n");
		System.out.print("Nome: ");
		n = in.readLine();													// lê o nome do fornecedor
		System.out.print("Código: ");
		c = Integer.parseInt(in.readLine());
		System.out.print("Telefone: ");
		t = in.readLine();													// lê o nome do fornecedor
		System.out.println("***********************************************************************");

		Fornecedor f = new Fornecedor(n,t,c);								// cria o objeto fornecedor

		Produto p = new Produto("Varinha mágica", 2300);						// cria um produto
		p.setEstoque(10);
		p.setEstoqueMinimo(5);
		Perecivel pp = new Perecivel("Asa de morcego", 20, 31,10,2016);		// cria um produto perecível
		pp.setEstoque(15);
		pp.setEstoqueMinimo(20);

		Item i1 = new Item(1,2,p);											// cria um item ligado ao produto p
		Item i2 = new Item(2,10,pp);										// cria um item ligado ao produtoPerecivel pp
		
		Cliente comprador = new Cliente("Hermione Granger João","123.456.789-00","Escola de Magia e Bruxaria de Hogwarts");
		Data hoje = new Data(30,9,2016);
		Pedido pedido = new Pedido(123,comprador,"Garrick Ollivander", hoje);
		System.out.println("\n***********************************************************************");
		System.out.print(pedido);												// imprime pedido vazio
		System.out.println("\n***********************************************************************");
		pedido.adicionaItem(i1);
		pedido.adicionaItem(i2);
		System.out.print(pedido);												// imprime pedido com 2 itens
		System.out.println("\n***********************************************************************");
		System.out.print(pp);													// mostra que o estoque do pp foi diminuido
		System.out.println("\n***********************************************************************");
		pedido.removeItem(2);
		System.out.print(pedido);												// imprime pedido com 1 item
		System.out.println("\n***********************************************************************");
		System.out.print(pp);													// mostra que o estoque do pp foi reestabelecido
		System.out.println("\n***********************************************************************");
	}	
}
