/*
 * Data.java
 * 
 * Última modificação: 20/08/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */

/**
 *  Solução da classe Data.java do Lab4
 */
public class Data
{
	private int dia;		// propriedade data
	private int mes;		// coordenada y do centro da forma
	private int ano;		// nome da forma
		
	public Data(int dia, int mes, int ano) {  
		this.dia = dia;
		this.mes = mes;
		this.ano = ano;
	}
	
	public int getDia() {
		return dia;
	}
	
	public int getMes() {
		return mes;
	}
	
	public int getAno() {
		return ano;
	}

	/*   @Override   */
	public String toString() {
		String out = ""; 
		out += getDia() + "/" + getMes() +"/" + getAno();
		return out; 
    }
}