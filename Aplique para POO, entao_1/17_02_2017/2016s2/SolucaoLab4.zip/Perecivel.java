/*
 * Perecivel.java
 * 
 * Última modificação: 24/09/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */

import java.util.Calendar;

/**
 *  Classe Perecivel referente ao Lab2
 *  Herda de Produto.java
 */
public class Perecivel extends Produto
{
	private int validade[];			// propriedade data de validade
	
	public Perecivel(String descricao,float valor,int dia, int mes, int ano) {
		super(descricao,valor);
		validade = new int[3];
		validade[0] = dia;
		validade[1] = mes;
		validade[2] = ano;
	}
	
	public boolean estaVencido() {  
		Calendar hoje = Calendar.getInstance(); 				// Data atual do sistema
		Calendar val = Calendar.getInstance(); 	    			// Data atual do sistema
		val.set(validade[2], validade[1]-1, validade[0]);		// ano, mes (indexado a partir de 0), dia
		
		if (val.after(hoje))
			return false;
		else
			return true;
	}

	public void aplicarDesconto(float desconto) {  
		setValor(getValor()-(getValor()*desconto/100));
	}
	
	public String toString () {
		String out = "";
		out += super.toString();
		out += "\nValidade: " + validade[0] + "/" + validade[1] + "/" +validade[2];
		return out;
	}
}
  
  
  
  
  
  
