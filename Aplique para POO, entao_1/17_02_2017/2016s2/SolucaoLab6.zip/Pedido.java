/*
 * Pedido.java
 * 
 * Última modificação: 20/08/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */

import java.util.ArrayList;

/**
 *  Esta classe contém a estrutura de implementação de um Pedido em uma associação Pedido-tem-Item e Pedido-tem-Data
 *  Usa as classes Item.java, Data.java e Cliente.java e a Interface Calculavel.java
 */
public class Pedido implements Calculavel, Comparable<Pedido>
{
	private int numero;					// propriedade número do pedido
	private String vendedor;			// propriedade nome do vendedor
	private Data dia;					// propriedade data do pedido
	private Cliente comprador;			// propriedade comprador do pedido
	private ArrayList<Item> itens;		// propriedade itens do pedido
	
	public Pedido(int numero, Cliente comprador, String vendedor,Data dia) {
    	this.numero = numero;
    	this.vendedor = vendedor;
    	this.dia = dia;
		this.comprador = comprador;
    	itens = new ArrayList<Item>(); 
    }
	
	public int getNumero() {
		return numero;
	}
	
	public String getVendedor() {
		return vendedor;
	}
	
	public Data getData() {
		return dia;
	}

	public Cliente getComprador() {
		return comprador;
	}
	
	public void adicionaItem(Item i) {
    	/* So adiciona item se tiver quantidade em estoque do produto 
			O método aproveita para chamar o baixarEstoque */
		if ((i.getProduto()).baixarEstoque(i.getItens()))
			itens.add(i);  
    }
	
	public boolean removeItem(int n) {
    	/* Remove o item na n-esima posicao do vetor */
		if (itens.size() >= n-1) {
			Item i = itens.get(n-1);
			itens.remove(n-1);  
			(i.getProduto()).aumentarEstoque(i.getItens());
			return true;
		} else
			return false;
    }
	
	public double calcularCusto() {
    	double total = 0f;
		Item umItem; 
		
    	for(int i=0; i<itens.size(); i++) {
			umItem = itens.get(i);
		  	total = total + (umItem.calcularCusto());
      	}
    	return total;  
	}
	
    public int compareTo(Pedido outroPedido) {
        if (this.calcularCusto() < outroPedido.calcularCusto()) {
            return -1;
        }
        if (this.calcularCusto()  > outroPedido.calcularCusto()) {
            return 1;
        }
        return 0;
    }	
	
	/*   @Override   */
	public String toString() {
		String out = ""; 
		Item umItem;
		
		out += "Pedido # "+ getNumero(); 
		out += " do vendedor " + getVendedor() + "\n"; 
		out += "Data: " + getData();
		out += "\n" + comprador;
		out += "\nItens:\n";
	    for(int i=0; i<itens.size(); i++) {
			umItem = itens.get(i);
			out += "  * " + umItem + "\n";
		}
	    out += "Total do pedido: "+ calcularCusto();
		return out; 
    }
}