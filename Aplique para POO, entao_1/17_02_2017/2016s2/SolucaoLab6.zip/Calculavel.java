/*
 * Calculavel.java
 * 
 * Última modificação: 01/11/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */

/**
 *  Define a Interface Calculavel
 */
public interface Calculavel { 
	double calcularCusto(); 
}
