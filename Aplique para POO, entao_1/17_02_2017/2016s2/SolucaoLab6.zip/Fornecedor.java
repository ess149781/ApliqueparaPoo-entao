/*
 * Fornecedor.java
 * 
 * Última modificação: 24/09/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */


/**
 *  Classe Produto referente ao Lab3
 */
public class Fornecedor {
	
	private String razaoSocial;					// propriedade razão social do fornecedor
  	private String telefone;					// propriedade telefone do fornecedor
  	private int codigo;							// propriedade código do do fornecedor

	public Fornecedor(String razaoSocial,String telefone, int codigo) { 
		this.razaoSocial = razaoSocial; 
		this.telefone = telefone;
		this.codigo = codigo;
	} 

	public String getRazaoSocial() { 
		return razaoSocial; 
	} 

	public String getTelefone() { 
		return razaoSocial; 
	} 
	
	public int getCodigo() { 
		return codigo; 
	} 
		
	public void setRazaoSocial(String razaoSocial) { 
		this.razaoSocial = razaoSocial; 
	} 

	public void setTelefone(String telefone) { 
		this.telefone = telefone; 
	} 
	
	public void setCodigo(int codigo) { 
		this.codigo = codigo; 
	} 

	public String toString () {
		String out = "";
		out += "Fornecedor (" + getCodigo() + ") " + getRazaoSocial() + " telefone - " + getTelefone();
		return out;
	}
}
