/*
 * Item.java
 * 
 * Última modificação: 26/09/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */

/**
 *  Classe Item referente ao Lab3
 *  Usa Produto.java
 */
public class Item {
	private int id;					// propriedade id do item
	private int itens;				// propriedade número de produtos 
	private Produto produto;		// propriedade produto ao qual o item se refere
	
	public Item(int id, int itens, Produto produto) {
		this.id = id;
		this.itens = itens;
		this.produto = produto;
	}
	
	public void setProduto(Produto produto) {
		this.produto = produto;
	}
	
	public Produto getProduto() {
		return produto;
	}
	
	public void setItens(int itens) {
		this.itens = itens;
	}
	
	public int getItens() {
		return itens;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}

	public float calculaCusto() {
		return produto.getValor() * itens;
	}
	
	public String toString(){
		String out = "";
		out += "Item código: "+ getId() + " quantidade de produtos: " + getItens()+ "\n" ;
		out += getProduto() + "\n";
		return out;
	}
}
