/*
 * VendaPrazo.java
 * 
 * Última modificação: 20/08/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */

/**
 *  Esta classe contém a estrutura de implementação de uma VendaPrazo
 *  Herda de Venda.java
 */
public class VendaPrazo extends Venda {
	private double juros;
	
	public VendaPrazo(Data d, double juros)
	{
		super(d);
		this.juros =  juros;
	}
	
	/* Método que calcula o total bruto de uma venda a prazo */
	public double getTotal() {
		double total = 0.0;
		for (int i=0; i<pedidos.size(); ++i) {
			total += (double)(pedidos.get(i)).calculaTotal();
		}
		return (total  * (100+juros))/100;
	}
		
	/*   @Override   */
	public String toString() {
		String out = ""; 
		out += super.toString();
		out += "\nTotal da venda com juros:" + getTotal() + "\n";
		return out; 
    }
	
}