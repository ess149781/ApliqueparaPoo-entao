/*
 * VendaVista.java
 * 
 * Última modificação: 20/08/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */

/**
 *  Esta classe contém a estrutura de implementação de uma VendaVista
 *  Herda de Venda.java
 */
public class VendaVista extends Venda{
	private double desconto;
	
	public VendaVista(Data d, double desconto)
	{
		super(d);
		this.desconto =  desconto;
	}
	
	/* Método que calcula o total bruto de uma venda a vista */
	public double getTotal() {
		double total = 0.0;
		for (int i=0; i<pedidos.size(); ++i) {
			total += (double)(pedidos.get(i)).calculaTotal();
		}
		return (total * (100-desconto))/100;
	}
	
	/*   @Override   */
	public String toString() {
		String out = ""; 
		out += super.toString();
		out += "\nTotal da venda com desconto:" + getTotal() + "\n";
		return out; 
    }
}