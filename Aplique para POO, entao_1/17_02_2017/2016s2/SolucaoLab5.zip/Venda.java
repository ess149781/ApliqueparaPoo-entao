/*
 * Produto.java
 * 
 * Última modificação: 20/08/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */

import java.util.ArrayList;

/**
 *  Esta classe contém a estrutura de implementação de uma Venda 
 */

public abstract class Venda {
	protected ArrayList<Pedido> pedidos;
	private Data data;
	
	public Venda(Data d)
	{
		pedidos = new ArrayList<Pedido>();		
		data = d;
	}
	
	public void adicionaPedido(Pedido i) {
    	pedidos.add(i);  
    }
	
	/* Método que deve calcular o total bruto de uma venda */
	public abstract double getTotal();
	
	/*   @Override   */
	public String toString() {
		String out = ""; 
		
		out += "Venda na data "+ data; 
		out += "\nPedidos:\n";
	    for(int i=0; i<pedidos.size(); i++) {
			out += "  * " + pedidos.get(i) + "\n";
		}
		return out; 
    }
}