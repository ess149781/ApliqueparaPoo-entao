/*
 * TestePedido.java
 * 
 * Última modificação: 01/10/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
/**
 *  Classe utilizada para instaciar objetos da classe Produto, Perecivel, Item, Fornecedor, Cliente, Pedido, Venda, 
 *  VendaVista e VendaPrazo
 *  referente ao lab 5
 *  Usa as classes Produto.java, Perecivel.java, Item.java, Fornecedor.java, Cliente.java, Data.java, Pedido.java,
 *  Venda.java, VendaVista.java e VendaPrazo.java
 */

public class TesteVenda
{
	public static void main(String[] argv) throws Exception 
	{
		ArrayList<Venda> vendas = new ArrayList<Venda>();
		String n, t;
		int c;

		InputStreamReader reader = new InputStreamReader(System.in);
		BufferedReader in = new BufferedReader(reader);

		System.out.println("***********************************************************************");
		System.out.print("Entre com as informações do fornecedor:\n");
		System.out.print("Nome: ");
		n = in.readLine();													// lê o nome do fornecedor
		System.out.print("Código: ");
		c = Integer.parseInt(in.readLine());
		System.out.print("Telefone: ");
		t = in.readLine();													// lê o nome do fornecedor
		System.out.println("***********************************************************************");

		Fornecedor f = new Fornecedor(n,t,c);								// cria o objeto fornecedor

		Produto p = new Produto("Varinha mágica", 2300);					// cria um produto
		p.setEstoque(10);
		p.setEstoqueMinimo(5);
		Perecivel pp = new Perecivel("Asa de morcego", 20, 31,10,2016);		// cria um produto perecível
		pp.setEstoque(15);
		pp.setEstoqueMinimo(20);

		Item i1 = new Item(1,2,p);											// cria um item ligado ao produto p
		Item i2 = new Item(2,10,pp);										// cria um item ligado ao produtoPerecivel pp
		Item i3 = new Item(4,5,p);											// cria um item ligado ao produtoPerecivel pp
		
		Cliente comprador = new Cliente("Hermione Granger","123.456.789-00","Escola de Magia e Bruxaria de Hogwarts");
		Cliente comprador2 = new Cliente("Harry Potter","008.999.666-10","Escola de Magia e Bruxaria de Hogwarts");
		Data hoje = new Data(30,9,2016);
		Data amanha = new Data(7,11,2016);
		Pedido pedido = new Pedido(123,comprador,"Garrick Ollivander", hoje);
		Pedido pedido2 = new Pedido(345,comprador2,"Sirius", amanha);

		pedido.adicionaItem(i1);
		pedido.adicionaItem(i2);
		pedido2.adicionaItem(i2);
		pedido2.adicionaItem(i1);
		pedido2.adicionaItem(i3);

		int i,j;
		do {
			System.out.println("\n***********************************************************************");
			System.out.print("Nova venda (1), Relatório de Vendas (2) ou Finalizar (3):\n");
			i = Integer.parseInt(in.readLine());		
			if (i==1) {
				System.out.println("*********************** Checando tipo de venda ************************");	
				System.out.print("Deseja realizar uma venda a vista (1) ou a prazo (2): ");
				j = Integer.parseInt(in.readLine());		
				if (j==1){
					vendas.add(new VendaVista(new Data(10,10,2016), 10));
					(vendas.get(vendas.size()-1)).adicionaPedido(pedido);
				}
				else if (j==2) {
					vendas.add(new VendaPrazo(new Data(20,9,2016), 7));
					(vendas.get(vendas.size()-1)).adicionaPedido(pedido);
					(vendas.get(vendas.size()-1)).adicionaPedido(pedido2);
				}
			} else if (i==2) {
				System.out.println("\n***********************************************************************");
				System.out.println("************************ Relatório de Vendas **************************");	
				for (j=0; j<vendas.size(); ++j) {
					System.out.println("****************************** Venda #" + (j+1) + " *******************************\n");	
					System.out.print(vendas.get(j));	
				}
			}
		} while (i!=3);
	}	
}
