package base;

import base.cartas.*;
import base.cartas.magias.*;
import Util.Util;

public class Main {
	public static void main(String[] args) {
                // A classe carta é abstrata e não pode ser instanciada
                Carta  card1 =  new Carta("Frodo Bolseiro", 2);                
                //Carta  card3 =  new Carta();
                Lacaio lac1  =  new Lacaio("Frodo Bolseiro", 2,1,2,3);
		//Lacaio lac2  =  new Lacaio();
		//Lacaio lac3  =  new Lacaio();
                // A classe Magia é abstrata e não pode ser instanciada
		//Magia  mag1  =  new Magia("Telecinese", 3);
		//Magia  mag2  =  new Magia();
                
                
		
	}
}
