public interface DoIt {
	int doSomething(int i, int j);
   	int doSomethingElse(String s);
   	static boolean didItWork() {
         System.out.println("Não tenho a menor ideia!");
	}
}


