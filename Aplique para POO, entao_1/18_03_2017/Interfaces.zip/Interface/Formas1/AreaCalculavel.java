/*
 * AreaCalculavel.java
 * 
 * Última modificação: 01/10/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */

/**
 *  Define a Interface AreaCalculavel
 */
interface AreaCalculavel {
	double calculaArea();
}
