/*
 * TesteProduto.java
 * 
 * Última modificação: 20/08/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *  Classe utilizada para instaciar objetos da classe Produto e Perecivel referente ao lab 2
 *  Usa as classes Produto.java e Perecivel.java
 */

public class TesteProduto 
{
	public static void main(String[] argv) throws Exception 
	{
		int op=0;
		String desc;
		float valor;
		int d,m,a;
		do 
		{
    		System.out.println("***********************************************************************");
    		System.out.print("Entre com a opção 1) Criar produto 2) Criar produto perecível 3) Sair: ");
    		InputStreamReader reader = new InputStreamReader(System.in);
    		BufferedReader in = new BufferedReader(reader);
    		op = Integer.parseInt(in.readLine());
			switch(op)
			{
				case 1: 
	    			System.out.print("Nome do produto: ");
					desc = in.readLine();
	    			System.out.print("Valor do produto: ");
					valor = Float.parseFloat(in.readLine());
					Produto p = new Produto(desc, valor);
					System.out.println(p);
					break;
				case 2:
					System.out.print("Nome do produto: ");
					desc = in.readLine();
					System.out.print("Valor do produto: ");
					valor = Float.parseFloat(in.readLine());
					System.out.print("Validade do produto: dia ");
					d = Integer.parseInt(in.readLine());
					System.out.print("Validade do produto: mes ");
					m = Integer.parseInt(in.readLine());
					System.out.print("Validade do produto: ano ");
					a = Integer.parseInt(in.readLine());
					Perecivel pp = new Perecivel(desc, valor, d, m, a);
					System.out.println(pp);
					System.out.printf("O produto %s esta vencido.\n", pp.estaVencido() ? "" : "não");
					pp.aplicarDesconto(10);
					System.out.println(pp);
					break;
				case 3:
					break;
			}
		} while (op != 3);
	}		

}
