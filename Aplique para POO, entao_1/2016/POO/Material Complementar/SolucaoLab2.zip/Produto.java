/*
 * Produto.java
 * 
 * Última modificação: 24/09/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */


/**
 *  Classe Produto referente ao Lab2
 */
public class Produto {
	
    private static int quantidade=0; 		// variável de classe - número de produtos criados
	private String descricao;				// propriedade descricao do produto
  	private String foto;					// propriedade caminho para foto do produto
  	private int id;							// propriedade id do produto
  	private float valor;					// propriedade valor do produto
  

	public Produto(String descricao,float valor) { 
		quantidade++; 
		id = quantidade;
		this.descricao = descricao; 
		this.valor = valor;
		this.foto = "produto sem foto";
	} 

	public String getDescricao() { 
		return descricao; 
	} 

	public String getFoto() { 
		return foto; 
	} 
	
	public float getValor() { 
		return valor; 
	} 

	public int getId() { 
		return id; 
	} 
	
	public static int getQuantidade() { 
		return quantidade; 
	} 
	
	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public void setFoto(String foto) { 
		this.foto = foto; 
	} 
	
	public void setValor(float valor) { 
		this.valor = valor; 
	} 

	public void setId(int id) { 
		this.id = id; 
	} 
	
	public String toString () {
		String out = "";
		out += "Produto (" + getId() + ") " + getDescricao() + " custa R$" + getValor();
		return out;
	}
}
  
  
  
