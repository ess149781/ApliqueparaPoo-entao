/*
 * Produto.java
 * 
 * Última modificação: 24/09/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */


/**
 *  Classe Produto referente ao Lab3
 *  Usa Fornecedor.java
 */
public class Produto {
	
    private static int quantidade=0; 		// variável de classe - número de produtos criados
	private String descricao;				// propriedade descricao do produto
  	private String foto;					// propriedade caminho para foto do produto
  	private int id;							// propriedade id do produto
  	private float valor;					// propriedade valor do produto
	private Fornecedor fornecedor;			// propriedade fornecedor
  	private int estoque;					// propriedade quantidade em estoque do produto
  	private int estoqueMinimo;				// propriedade estoque mínimo do produto
	

	public Produto(String descricao,float valor) { 
		quantidade++; 
		id = quantidade;
		this.descricao = descricao; 
		this.valor = valor;
		this.foto = "produto sem foto";
		estoque = 0;
		estoqueMinimo = 5; 			// ou alguma valor padrão
	} 

	public String getDescricao() { 
		return descricao; 
	} 

	public String getFoto() { 
		return foto; 
	} 
	
	public float getValor() { 
		return valor; 
	} 

	public int getId() { 
		return id; 
	} 
	
	public int getEstoque() { 
		return estoque; 
	}
	 
	public int getEstoqueMinimo() { 
		return estoqueMinimo; 
	}

	public static int getQuantidade() { 
		return quantidade; 
	} 
	
	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public void setFoto(String foto) { 
		this.foto = foto; 
	} 
	
	public void setValor(float valor) { 
		this.valor = valor; 
	} 

	public void setId(int id) { 
		this.id = id; 
	} 

	public void setEstoque(int estoque) { 
		this.estoque = estoque; 
	} 
	
	public void setEstoqueMinimo(int estoqueMinimo) { 
		this.estoqueMinimo = estoqueMinimo; 
	} 

	public boolean checarEstoqueMinimo() {
		if (estoque > estoqueMinimo)
			return false;
		else
			return true;
	}

	public String toString () {
		String out = "";
		out += "Produto (" + getId() + ") " + getDescricao() + " custa R$" + getValor() + "\n";
		out += "Quantidade em estoque: " + getEstoque() + "\n";
		out += "Estoque mínimo ";
		if (!checarEstoqueMinimo())
			out+= "não ";
		out+= "atingido";
		return out;
	}
}
  
  
  
