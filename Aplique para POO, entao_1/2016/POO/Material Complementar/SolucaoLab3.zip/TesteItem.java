/*
 * TesteItem.java
 * 
 * Última modificação: 26/09/2016 
 * 
 * Material utilizado na disciplina MC322 - Programação Orientada a Objetos
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *  Classe utilizada para instaciar objetos da classe Produto, Perecivel, Item e Fornecedor referente ao lab 3
 *  Usa as classes Produto.java, Perecivel.java, Item.java e Fornecedor.java
 */

public class TesteItem 
{
	public static void main(String[] argv) throws Exception 
	{
		String n, t;
		int c;

		InputStreamReader reader = new InputStreamReader(System.in);
		BufferedReader in = new BufferedReader(reader);

		System.out.println("***********************************************************************");
		System.out.print("Entre com as informações do fornecedor:\n");
		System.out.print("Nome: ");
		n = in.readLine();													// lê o nome do fornecedor
		System.out.print("Código: ");
		c = Integer.parseInt(in.readLine());
		System.out.print("Telefone: ");
		t = in.readLine();													// lê o nome do fornecedor
		System.out.println("***********************************************************************");

		Fornecedor f = new Fornecedor(n,t,c);								// cria o objeto fornecedor

		Produto p = new Produto("TV LED 42''", 2300);						// cria um produto
		p.setEstoque(10);
		p.setEstoqueMinimo(5);
		Perecivel pp = new Perecivel("Leite Molico", 2300, 31,10,2016);		// cria um produto perecível
		pp.setEstoque(15);
		pp.setEstoqueMinimo(20);

		Item i1 = new Item(1,2,p);											// cria um item ligado ao produto p
		Item i2 = new Item(2,10,pp);										// cria um item ligado ao produtoPerecivel pp
		
		System.out.println("***********************************************************************");
		System.out.print(i1);												// imprime dados do item 1
		System.out.println("***********************************************************************");
		System.out.print(i2);												// imprime dados do item 2
		System.out.println("***********************************************************************");
	}	
}
